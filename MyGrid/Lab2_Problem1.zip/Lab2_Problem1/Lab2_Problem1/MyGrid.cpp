/*
Author: Peiyu Han
Class: ECE6122
Last Date Modified: 2020/10/01
Description: the implemention of all the member functions

What is the purpose of this file?
to fullfill all the member functions clearly
*/

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include "MyGrid.h"

/******************************************************************/
//class constructor
/******************************************************************/
MyGrid::MyGrid(void)
{
	cout << "MyGrid is being created" << end1;
}

/******************************************************************/
// load grid from the file and decide whether it is successful
/******************************************************************/
bool MyGrid::loadGridFromFile(const string& filename) 
{
	ifstream fin(filename);
	if (!fin.good())
	{
		return 0;
	}
	else
	{
		fin >> myX;
		fin >> myY;
		fin >> NumRows;
		fin >> NumCols;
		vector<vector<long>> elements(NumRows, vector<long>(NumCols));
			for (int i = 0; i < NumRows; i++ )
			{
				for (int j = 0; j < NumCols; j++)
				{
					fin >> elements[i][j];
					this->gridElements = elements;
				}
		    }
		return 1;
	}
}

/******************************************************************/
// set all elements to 0
/******************************************************************/
void MyGrid::zeroOutGrid()
{
	for (int ii = 0; ii < NumRows; ii++)
	{
		for (int jj = 0; jj < NumCols; jj++)
		{
			gridElements[ii][jj] = 0;
		}
	}
}

/******************************************************************/
// get the NumRows
/******************************************************************/
long MyGrid::getNumRows() const
{
	return NumRows;
}

/******************************************************************/
// get the NumCols
/******************************************************************/
long MyGrid::getNumCols() const
{
	return NumCols;
}

/******************************************************************/
// Addition Operator (add two grids)
// V3 = V1 + V2
/******************************************************************/
MyGrid MyGrid:: operator+(MyGrid const& rhs) const
{
	MyGrid newgrid(*this);
	long TmyXl = min(newgrid.myX, rhs.myX);
	long TmyXr = max(newgrid.myX + newgrid.NumCols -1, rhs.myX + rhs.NumCols -1);
	long TmyYt = max(newgrid.myY, rhs.myY);
	long TmyYd = min(newgrid.myY - newgrid.NumRows +1, rhs.myY - rhs.NumRows + 1);

	TCols = TmyXr - TmyXl + 1;
	TRows = TmyYt - TmyYd + 1;

	long arrayA[TRows][TCols] = 0;
	long arrayB[TRows][TCols] = 0;
	long arrayT[TRows][TCols] = 0;

	for (int i = 0; i < newgrid.NumRows; i++)
	{
		for (int j = 0; j < newgrid.NumCols; j++)
		{
			arrayA[newgrid.myX + j][newgrid.myY - i ] == newgrid.gridElements[i][j];
		}
	}

	for (int ii = 0; ii < rhs.NumRows; ii++)
	{
		for (int jj = 0; jj < rhs.NumCols; jj++)
		{
			arrayB[rhs.myX + jj][rhs.myY - ii] == rhs.gridElements[ii][jj];
		}
	}

	for (int iii = 0; iii < TRows; iii++)
	{
		for (int jjj = 0; jjj < TCols; jjj++)
		{
			arrayT[iii][jjj] == arrayA[iii][TRows - jjj] + arrayB[iii][TRows - jjj];
		}
	}

	newgrid.myX = TmyXl;
	newgrid.myY = TmyYt;
	newgrid.NumRows = TRows;
	newgrid.getNumCols = TCols;
	newgrid.gridElements = arrayT;

	return newgrid;
}

/******************************************************************/
// Subtraction Operator (one grid mminus another)
// V3 = V1 - V2
/******************************************************************/
MyGrid MyGrid:: operator+(MyGrid const& rhs) const
{
	MyGrid newgrid(*this);
	long TmyXl = min(newgrid.myX, rhs.myX);
	long TmyXr = max(newgrid.myX + newgrid.NumCols - 1, rhs.myX + rhs.NumCols - 1);
	long TmyYt = max(newgrid.myY, rhs.myY);
	long TmyYd = min(newgrid.myY - newgrid.NumRows + 1, rhs.myY - rhs.NumRows + 1);

	long TCols = TmyXr - TmyXl + 1;
	long TRows = TmyYt - TmyYd + 1;

	long arrayA[TRows][TCols] = 0;
	long arrayB[TRows][TCols] = 0;
	long arrayT[TRows][TCols] = 0;

	for (int i = 0; i < newgrid.NumRows; i++)
	{
		for (int j = 0; j < newgrid.NumCols; j++)
		{
			arrayA[newgrid.myX + j][newgrid.myY - i] = newgrid.gridElements[i][j];
		}
	}

	for (int ii = 0; ii < rhs.NumRows; ii++)
	{
		for (int jj = 0; jj < rhs.NumCols; jj++)
		{
			arrayB[rhs.myX + jj][rhs.myY - ii] = rhs.gridElements[ii][jj];
		}
	}

	for (int iii = 0; iii < TRows; iii++)
	{
		for (int jjj = 0; jjj < TCols; jjj++)
		{
			arrayT[iii][jjj] = arrayA[iii][TRows - jjj] - arrayB[iii][TRows - jjj];
		}
	}

	newgrid.myX = TmyXl;
	newgrid.myY = TmyYt;
	newgrid.NumRows = TRows;
	newgrid.getNumCols = TCols;
	newgrid.gridElements = arrayT;

	return newgrid;
}

/******************************************************************/
// add a grid and a long constant
/******************************************************************/
MyGrid MyGrid::operator+(long const& Long) const
{
	MyGrid newgrid(*this);
	for (int i = 0; i < newgrid.NumRows; i++)
	{
		for (int j = 0; j < newgrid.NumCols; j++)
		{
			newgrid.gridElements[i][j] += Long;
		}
	}

	return newgrid;
}

/******************************************************************/
// add a long constant and a grid
/******************************************************************/
MyGrid operator+(long const& lhs, MyGrid const& rhs)
{
	MyGrid newgrid(rhs);
	return (newgrid + lhs);
}

/******************************************************************/
// Addition Assignment Operator 
/******************************************************************/
MyGrid& MyGrid: operator += (MyGrid const& rhs)
{
	for (int ii = 0; ii < NumRows; ii++)
	{
		for (int jj = 0; jj < NumCols; jj++)
		{
			this->gridElements[ii][jj] += rhs.gridElements[ii][jj];
		}
	}

	return *this;
}

/******************************************************************/
// Prefix Increment Operator 
/******************************************************************/
MyGrid& MyGrid::operator++()
{
	for (int i = 0; i < NumRows; i++)
	{
		for (int j = 0; j < NumCols; j++)
		{
			gridElements[i][j] ++;
		}
	}

	return *this;
}

/******************************************************************/
// Postfix Increment Operator 
/******************************************************************/
MyGrid MyGrid::operator++(int)
{
	for (int ii = 0; ii < NumRows; ii++)
	{
		for (int jj = 0; jj < NumCols; jj++)
		{
			MyGrid temp[ii][jj] = *this;
			++(*this);
		}
	}

	return temp;
}

/******************************************************************/
// Prefix Increment Operator 
/******************************************************************/
MyGrid& MyGrid::operator--()
{
	for (int i = 0; i < NumRows; i++)
	{
		for (int j = 0; j < NumCols; j++)
		{
			gridElements[i][j] --;
		}
	}

	return *this;
}

/******************************************************************/
// Postfix Increment Operator 
/******************************************************************/
MyGrid MyGrid::operator--(int)
{
	for (int ii = 0; ii < NumRows; ii++)
	{
		for (int jj = 0; jj < NumCols; jj++)
		{
			MyGrid temp[ii][jj] = *this;
			--(*this);
		}
	}

	return temp;
}

/******************************************************************/
//Negation Operator
/******************************************************************/
MyGrid MyGrid::operator-() const
{
	MyGrid tmpgrid;
	for (int i = 0; i < NumRows; i++)
	{
		for (int j = 0; j < NumCols; j++)
		{
			tmpgrid.gridElements[i][j] = -tmpgrid.gridElements[i][j];
		}
	}

	return tmpgrid;
}

/******************************************************************/
// Equality Operator
/******************************************************************/
bool MyGrid:: operator== (MyGrid const& rhs) const
{
	if ((myX == rhs.myX) && (myY == rhs.myY) && (NumRows == rhs.NumRows) && (NumCols == rhs.NumCols))
	{
		for (int ii = 0; ii < NumRows; ii++)
		{
			for (int jj = 0; jj < NumCols; jj++)
			{
				if (gridElements[ii][jj] != rhs.gridElements[ii][jj])
				{
					return 0;
					break;
				}
				else if ((ii == NumRows) && (jj == NumCols) && (gridElements[ii][jj] == rhs.gridElements[ii][jj]))
				{
					return 1;
				}
				else
					continue;
			}
		}
	}
	else
	{
		return 0;
	}
}

/******************************************************************/
// File stream insertion operator
/******************************************************************/
fstream& operator<<(fstream& os, const MyGrid& gridIn)
{
	os << "myX: " << gridIn.myX << endl;
	os << "myY: " << gridIn.myY << endl;
	os << "NumRows: " << gridIn.NumRows << endl;
	os << "NumCols: " << gridIn.NumCols << endl;
	os << "gridElements: " << gridIn.gridElements << end1;
}